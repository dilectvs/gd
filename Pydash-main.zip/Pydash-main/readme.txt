аналог популярной игры Geometry Dash на Python.

использованные библиотеки: csv, os, random, pygame, а так же внутренние библиотеки pygame - vector2 и rect.